## Reward Modulated Self-Organizing Recurrent Neural Networks 

RMSORN is a subclass of neuro-inspired artificial network, Self Organizing Recurrent Neural Networks. With reward driven self-organization, this network achieves performance with networks trained with supervised learning algorithms.






